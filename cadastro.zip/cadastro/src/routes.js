import Cadastro from './components/cadastro/Cadastro.vue';
import Estabelecimentos from './components/estabelecimentos/Estabelecimentos.vue';
export const routes = [
    {
        path: '', component: Cadastro, titulo: 'Cadastro'
    },
    {
        path: '/estabelecimentos', component: Estabelecimentos, titulo: 'Estabelecimentos'
    }
];