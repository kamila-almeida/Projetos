<template>
    <b-button variant="outline-secondary" class="botao" @click="disparaAcao()" :type="tipo">{{ rotulo }}</b-button>
</template>

<script>
export default{
    props: {
        tipo: {
            required: true,
            type: String
        },

        rotulo: {
            required: true,
            type: String
        },

        confirmacao: Boolean
    },

    methods: {
        disparaAcao() {

            if (this.confirmacao) {
                if (confirm('Confirma operação ?')) {
                    this.$emit('botaoAtivado');
                }
                return;
            }
            this.$emit('botaoAtivado');
        }
    }
}
</script>

<style scoped>

.botao {
    margin-top: 10px;
}

</style>