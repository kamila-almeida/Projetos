<template>

    <div class="cartao">
        <b-card bg-variant="dark" text-variant="white" :title="titulo">
        <b-card-text>{{ endereco }}</b-card-text>
        <b-button href="#" variant="primary">Editar</b-button>
        </b-card>
    </div>            
   
</template>

<script>
  export default{
      props: ['titulo'],
      endereco: ''
  }

</script>

<style lang="scss" scoped>
</style>
