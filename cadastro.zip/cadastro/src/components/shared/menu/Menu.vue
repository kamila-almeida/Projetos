<template>
<div>
    <b-navbar toggleable="lg" type="light" variant="dark">
        <b-navbar-brand><b-img rounded class="icone" src="./src/img/icone-est.png"></b-img></b-navbar-brand>
        <b-collapse id="nav-collapse" is-nav>
            <b-navbar-nav v-for="rota in rotas">
                <b-nav-item>
                    <router-link class="link-menu" :to="rota.path ? rota.path : '/'">{{ rota.titulo }}</router-link>
                </b-nav-item>
            </b-navbar-nav>
        </b-collapse>
    </b-navbar>
</div>
</template>

<script>
    export default{
        props: ['rotas']
    }
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Bree+Serif');
.icone {
    width: 50px;
    height: 50px;
}

.link-menu{
    text-decoration: none;
    font-family: 'Bree Serif', serif;
}

</style>