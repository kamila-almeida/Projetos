<template>
  <div>
    <b-container>
        <h1 class="centralizado">{{ titulo }}</h1>

        <b-form-input v-model="text" type="search" class="filtro" @input="filtro = $event.target.value" placeholder="Filtre por nome do estabelecimento"></b-form-input>
        
        <ul class="lista-cartoes">
            <li class="lista-cartoes-item" v-for="cartao of cartaoComFiltro">

                <cartao :titulo="cartao.titulo"></cartao>

            </li>
        </ul>
    </b-container>    
  </div> 
</template>

<script>
  import Card from '../shared/card/Card.vue';

  export default{
    components: {
      'cartao': Card
    },

    data() {
      return{
        titulo: 'Estabelecimentos',
        cartoes: [],
        filtro: ''
      }
    },

    computed:{
      cartaoComFiltro(){
        if (this.cartao){
          let exp = new RegExp(this.cartao.trim(), 'i');
          return this.cartoes.filter(cartao => exp.test(cartao.titulo));
        } else {
          return this.cartoes;
        }
      }
    },

    created() {
      
    }
  }

</script>

<style lang="scss">
  .centralizado {
    text-align: center;
  }

  .lista-catoes {
    list-style: none;
  }

  .lista-cartoes .lista-cartoes-item {
    display: inline-block;
  }  

</style>
