<template>
    <div>
    <b-container>
        <h1 class="centralizado">{{ titulo }}</h1>

        <b-form> 
            

            <label class="rotulo-cad">Nome:</label><b-form-input type="text" class="nome-est" @input="nome = $event.target.value" placeholder="Digite o nome do estabelecimento"/>
            <label class="rotulo-cad">Endereço:</label><places
                    v-model="form.country.label"
                    placeholder="Digite o endereço do estabelecimento"
                    @change="val => { form.country.data = val }"
                    :options="{ countries: ['BR'] }">
                </places>
            <meu-botao tipo="button" rotulo="Cadastrar" @botaoAtivado="salvaEstabelecimento()" :confirmacao="false"/>
        </b-form>
    </b-container>
         
  </div> 
</template>

<script>
    import Botao from '../shared/botao/Botao.vue';
    import Places from 'vue-places';

    export default{ 
        components: {
            'meu-botao': Botao,
            Places
        },       

        data() {
            return{
                titulo: 'Cadastro de Estabelecimentos',
                nome: '',
                endereco: '',
                form: {
                    country: {
                        label: null,
                        data: {} 
                    }
                }               
            }
        },

        methods: {
            salvaEstabelecimento() {
                if (!this.nome || !this.form.country.data) return;                
            }
        }
    }


</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Bree+Serif');

.centralizado, .rotulo-cad{
    font-family: 'Bree Serif', serif;
    margin-top: 10px;
}

</style>